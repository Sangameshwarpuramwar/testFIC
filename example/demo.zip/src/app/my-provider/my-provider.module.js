'use strict';

angular.module('myProviderModule', []);
